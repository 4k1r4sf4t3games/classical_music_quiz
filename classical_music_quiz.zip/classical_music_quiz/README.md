# Media Playback<br>
Nama Aplikasi : Advanced Android - Classical Music Quiz <br> <br>

# Identitas<br>
Nama lengkap : Bernadeth Rosalia Cika Andhini <br>
Kelas / No urut : XI RPL 4 / 10 <br>
NIS : 4686/1406.070 <br>
Angkatan : 24 <br>
Asal Sekolah : SMK Telkom Malang <br><br>

# Link APK<br>
https://drive.google.com/a/smktelkom-mlg.sch.id/file/d/0B3uFNV41E8onUEZwcVVKdFkzdms/view?usp=sharing

# Screenshoot Aplikasi<br>
![1](https://user-images.githubusercontent.com/22133514/29449886-ba45de88-8426-11e7-9d66-2a8cb7ec2933.png)<br>
![1 1](https://user-images.githubusercontent.com/22133514/29449887-bb7d6064-8426-11e7-83f2-0e4d75ed80bf.png)<br>
![2](https://user-images.githubusercontent.com/22133514/29449888-bbe1e78c-8426-11e7-87d9-8587a09c83fb.png)<br>
![3](https://user-images.githubusercontent.com/22133514/29449889-bbe8b88c-8426-11e7-9b5b-320249e3e902.png)<br>
![4](https://user-images.githubusercontent.com/22133514/29449890-bbf8b2f0-8426-11e7-9d5d-20416801126a.png)<br>


